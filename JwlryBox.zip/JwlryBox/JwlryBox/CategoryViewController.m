//
//  CategoryViewController.m
//  JwlryBox
//
//  Created by Vidhi Shah on 4/10/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import "CategoryViewController.h"
#import "Database.h"
#import "MasterViewController.h"
#import "InsertViewController.h"
#import "AppDelegate.h"


@interface CategoryViewController ()

@end

@implementation CategoryViewController
@synthesize category,imgv;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
//		self.toolbarItems =
//        [NSArray arrayWithObjects:
//         [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
//         
//							 [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(share)],
//         
//							 [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
//							 nil
//							 ];
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationItem.title = category;
//    
  // self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Bck.png"]];
//    
    //self.view.alpha = 2;

    
    NSString *dbcategory;
    if (category == @"All")
    {
        dbcategory =[NSString stringWithFormat:@"select * from Jewellery"];
        
    }
    else{
        
        
        dbcategory =[NSString stringWithFormat:@"select * from Jewellery where j_Category='%@'",category];
    }
   // dataArray = [Database executeQuery:dbcategory];
    dataArray = [[NSMutableArray alloc]initWithArray:[Database getList:dbcategory]];
    
    NSLog(@"%@",[dataArray description]);

    
    if (dataArray.count == 0)
    {
    
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
														message:@"No items stored."
													   delegate:self
											  cancelButtonTitle:@"OK"
											  otherButtonTitles:nil];
		[alert show];
        
    }
}



- (void)alertView : (UIAlertView *)alertView clickedButtonAtIndex : (NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"OK"])
    {
        MasterViewController *masterViewController = [[MasterViewController alloc] initWithNibName:@"MasterViewController_iPhone" bundle:nil];
      //  [self.navigationController pushViewController:masterViewController animated:YES];
    }
//    else if([title isEqualToString:@"Add"])
//    {
//        InsertViewController *masterViewController = [[InsertViewController alloc] initWithNibName:@"InsertViewController" bundle:nil];
//        [self.navigationController pushViewController:masterViewController animated:YES];
//    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataArray count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
   	cell.textLabel.numberOfLines=2;
    
    NSDictionary *dict1=[dataArray objectAtIndex:indexPath.row];
    
       // tableView.backgroundColor = [UIColor grayColor];
  
    
    
    UIImageView *imgv1 = [[UIImageView alloc]initWithFrame:CGRectMake(5, 5, 100,80)];
    
    //   [imgv1 setImage:[UIImage imageWithData:[NSData dataWithBytes:[data bytes] length:[data length]]]];
    if ([[dataArray objectAtIndex:indexPath.row] valueForKey:@"Image"] != nil) {
        
        
        NSData *tempData = [[NSData alloc]initWithData:[[dataArray objectAtIndex:indexPath.row] valueForKey:@"Image"]];
        
        
        NSLog(@"not nil data -- %@ " , tempData);
        
        UILabel *noImamge =[[UILabel alloc]init];
        noImamge.text = @"No Image";
        noImamge.textColor = [UIColor blueColor];
        
        noImamge.frame=CGRectMake(25, 20, 100,80 );
        [[cell contentView] addSubview:noImamge];

        
        [imgv1 setImage:[UIImage imageWithData:[[dataArray objectAtIndex:indexPath.row] valueForKey:@"Image"] ]];
        

        
    }
    
    else {
        NSLog(@"Image Data  nil");
        
        

        
    }
    
    [[cell contentView] addSubview:imgv1];
  
    
////    tableView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Bckgrnd.png"]];
////    
////    tableView.alpha = 2;
//
//    
//    NSData *dataImage = [dict1 objectForKey:@"j_Image"];
//    
//   //UIImage *img = [UIImage imageWithContentsOfFile:@"Icon.png"];
//
//
//   UIImage *img =[[UIImage alloc]initWithData:dataImage];
//    
// //  imgv = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 120, 50)];
//    
//  //  [imgv setImage:img];
//
//    
//     cell.imageView.image = [UIImage imageNamed:@"Icon.png"];
//    
//      //  [[cell imageView] setImage:img];
//    
//  //  [[cell contentView] addSubview:imgv];

    
    UILabel *lblDesc =[[UILabel alloc]init];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    lblDesc.textColor=[UIColor blackColor];
    lblDesc.frame=CGRectMake(115, -10, 185, 65);
    lblDesc.numberOfLines = 2;
    lblDesc.backgroundColor=[UIColor clearColor];
    NSString *strDesc =  [[dataArray objectAtIndex:indexPath.row] valueForKey:@"Desc"];

   // NSString *strDesc = [dict1 objectForKey:@"j_Desc"];
    lblDesc.text=strDesc;
    lblDesc.font = [UIFont systemFontOfSize:17];
    lblDesc.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
    [[cell contentView] addSubview:lblDesc];

    UILabel *lblWeight =[[UILabel alloc]init];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    lblWeight.textColor=[UIColor blackColor];
    lblWeight.frame=CGRectMake(115, 20, 185, 65 );
    lblWeight.numberOfLines = 2;
    lblWeight.backgroundColor=[UIColor clearColor];
   // NSString *strWeight = [dict1 objectForKey:@"j_Weight"];
    
    NSString *strWeight = [[dataArray objectAtIndex:indexPath.row] valueForKey:@"Price"];

    strWeight = [strWeight stringByAppendingString:@" gms "];
    lblWeight.text=strWeight;
    lblWeight.font = [UIFont systemFontOfSize:17];
    lblWeight.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
    [[cell contentView] addSubview:lblWeight];

    UILabel *lblPrice =[[UILabel alloc]init];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    lblPrice.textColor=[UIColor blackColor];
    lblPrice.frame=CGRectMake(115, 50, 185, 65 );
    lblPrice.numberOfLines = 2;
    lblPrice.backgroundColor=[UIColor clearColor];
    NSString *strPrice = @"$ ";
 // strPrice=  [strPrice stringByAppendingString:[dict1 objectForKey:@"j_Price"]];
    strPrice=  [strPrice stringByAppendingString: [[dataArray objectAtIndex:indexPath.row] valueForKey:@"Weight"]];
 
    lblPrice.text=strPrice;
    lblPrice.font = [UIFont systemFontOfSize:17];
    lblPrice.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
    [[cell contentView] addSubview:lblPrice];

    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.tag = indexPath.row;
    button.frame = CGRectMake(200, 15, 100, 50);
    [button setTitle:@"Share It" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(uploadFeedOnFacebook:) forControlEvents:UIControlEventTouchUpInside];
    [[cell contentView] addSubview:button];
    
    
    return cell;

}



- (void)uploadFeedOnFacebook:(id)sender {
        
    NSString *text =  [[dataArray objectAtIndex:[sender tag]] valueForKey:@"Desc"];
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    NSMutableDictionary *mDictFeedData = [NSMutableDictionary dictionary];
    
    [mDictFeedData setObject:@"Image" forKey:@"type"];
    [mDictFeedData setObject:@"http://www.google.com" forKey:@"URL"];
    [mDictFeedData setObject:text forKey:@"description"];
    [mDictFeedData setObject:@"jewellery" forKey:@"Title"];
    [mDictFeedData setObject:@"http://us.123rf.com/400wm/400/400/pongam/pongam1108/pongam110800007/10163399-pearl-necklace-in-the-treasure-box-isolated-on-white-background.jpg" forKey:@"ImagePath"];
    [appDelegate uploadFeed:mDictFeedData];
}

@end
