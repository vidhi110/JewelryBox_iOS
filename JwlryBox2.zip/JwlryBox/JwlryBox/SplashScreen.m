//
//  SplashScreen.m
//  JwlryBox
//
//  Created by Vidhi Shah on 4/10/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import "SplashScreen.h"
#import "MasterViewController.h"

@interface SplashScreen ()

@end

@implementation SplashScreen
-(void)tabbarPush{
	if (timer) {
		[timer invalidate];
		timer = nil;
	}
	
	MasterViewController *root = [[MasterViewController alloc] initWithNibName:@"MasterViewController_iPhone" bundle:nil];
	[self.navigationController pushViewController:root animated:YES];
	
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	[timer invalidate];
	timer=nil;
	
	[self tabbarPush];
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(tabbarPush) userInfo:nil repeats:NO];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
