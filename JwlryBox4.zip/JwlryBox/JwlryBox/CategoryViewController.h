//
//  CategoryViewController.h
//  JwlryBox
//
//  Created by Vidhi Shah on 4/10/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoryViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray    *dataArray;

    
    IBOutlet UIImageView *imgv;
    IBOutlet UIImage *img;
    
    NSString *category;

}
@property (nonatomic,retain) NSString *category;

@end
