//
//  CategoryViewController.m
//  JwlryBox
//
//  Created by Vidhi Shah on 4/10/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import "CategoryViewController.h"
#import "Database.h"
#import "MasterViewController.h"
#import "InsertViewController.h"

@interface CategoryViewController ()

@end

@implementation CategoryViewController
@synthesize category;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
       // self.title = category;

        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationItem.title = category;
    
    NSString *dbcategory;
    if (category == @"All")
    {
        dbcategory =[NSString stringWithFormat:@"select * from Jewellery"];
        
    }
    else{
        
        
        dbcategory =[NSString stringWithFormat:@"select * from Jewellery where j_Category='%@'",category];
    }
    dataArray = [Database executeQuery:dbcategory];
    
    
    if (dataArray.count == 0)
    {
    
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
														message:@"No items stored."
													   delegate:self
											  cancelButtonTitle:@"OK"
											  otherButtonTitles:nil];
		[alert show];
        
    }
}



- (void)alertView : (UIAlertView *)alertView clickedButtonAtIndex : (NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"OK"])
    {
        MasterViewController *masterViewController = [[MasterViewController alloc] initWithNibName:@"MasterViewController_iPhone" bundle:nil];
      //  [self.navigationController pushViewController:masterViewController animated:YES];
    }
//    else if([title isEqualToString:@"Add"])
//    {
//        InsertViewController *masterViewController = [[InsertViewController alloc] initWithNibName:@"InsertViewController" bundle:nil];
//        [self.navigationController pushViewController:masterViewController animated:YES];
//    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataArray count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
   	cell.textLabel.numberOfLines=1;
    
    NSDictionary *dict1=[dataArray objectAtIndex:indexPath.row];

    
    NSData *dataImage = [dict1 objectForKey:@"j_Image"];
    
    
  //  NSData *retrievedData = [NSData dataWithContentsOfFile:path];
    
    
    UIImageView *imgv = [[UIImageView alloc]
                         initWithFrame:CGRectMake(20,15,45,35)];
    
    
    imgv.image = [UIImage imageWithData:dataImage];
    [[cell contentView] addSubview:imgv];

//    UIImageView *imageView = [[UIImageView alloc]init];
//    imageView.frame = CGRectMake(20,15,45,35);
//
//    
//    UIImage *image = [[UIImage alloc]initWithData];
//    
//    image = [UIImage imageWithData:dataImage];
//    [imageView setImage:image];
//    [[cell contentView] addSubview:imageView];
    

    
    UILabel *lblDesc =[[UILabel alloc]init];    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    lblDesc.textColor=[UIColor blackColor];
    lblDesc.frame=CGRectMake(100, -10, 185, 65);
    lblDesc.numberOfLines = 2;
    lblDesc.backgroundColor=[UIColor clearColor];
    NSString *strDesc = [dict1 objectForKey:@"j_Desc"];
    lblDesc.text=strDesc;
    lblDesc.font = [UIFont systemFontOfSize:17];
    lblDesc.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
    [[cell contentView] addSubview:lblDesc];

    UILabel *lblWeight =[[UILabel alloc]init];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    lblWeight.textColor=[UIColor blackColor];
    lblWeight.frame=CGRectMake(100, 20, 185, 65 );
    lblWeight.numberOfLines = 2;
    lblWeight.backgroundColor=[UIColor clearColor];
    NSString *strWeight = [dict1 objectForKey:@"j_Weight"];
    strWeight = [strWeight stringByAppendingString:@" gms "];
    lblWeight.text=strWeight;
    lblWeight.font = [UIFont systemFontOfSize:17];
    lblWeight.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
    [[cell contentView] addSubview:lblWeight];

    UILabel *lblPrice =[[UILabel alloc]init];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    lblPrice.textColor=[UIColor blackColor];
    lblPrice.frame=CGRectMake(100, 50, 185, 65 );
    lblPrice.numberOfLines = 2;
    lblPrice.backgroundColor=[UIColor clearColor];
    NSString *strPrice = @"$ ";
  strPrice=  [strPrice stringByAppendingString:[dict1 objectForKey:@"j_Price"]];
    
    lblPrice.text=strPrice;
    lblPrice.font = [UIFont systemFontOfSize:17];
    lblPrice.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
    [[cell contentView] addSubview:lblPrice];

    
    return cell;

}

@end
