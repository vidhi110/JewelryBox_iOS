//
//  AppDelegate.h
//  JwlryBox
//
//  Created by Vidhi Shah on 4/6/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//
#import "Database.h"

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIActivityIndicatorView *indicator;

}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController *navigationController;

@property (strong, nonatomic) UISplitViewController *splitViewController;
@property(nonatomic,retain)IBOutlet UIActivityIndicatorView *indicator;


- (void)createEditableCopyOfDatabaseIfNeeded;



@end
