//
//  SplashScreen.h
//  JwlryBox
//
//  Created by Vidhi Shah on 4/10/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashScreen : UIViewController

{

    NSTimer *timer;

}
@end
