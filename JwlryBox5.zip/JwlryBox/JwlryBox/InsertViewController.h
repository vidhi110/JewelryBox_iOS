//
//  InsertViewController.h
//  JwlryBox
//
//  Created by Vidhi Shah on 4/6/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface InsertViewController : UIViewController<UIPickerViewDelegate, UIPickerViewDataSource,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITextFieldDelegate>
{

     IBOutlet UIPickerView *pickerView;
        NSMutableArray    *dataArray;
    
    NSString *strCategory;
    NSString *strDesc;

    NSString *strPrice;
    NSString *strWeight;

    UITextField *txtDesc;
    UITextField *txtPrice;
    UITextField *txtWeight;

    IBOutlet UIImageView *imageView;

}
@property (strong, nonatomic) IBOutlet UITextField *txtDesc;
@property (strong, nonatomic) IBOutlet UITextField *txtPrice;
@property (strong, nonatomic) IBOutlet UITextField *txtWeight;
@property BOOL newMedia;
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
- (IBAction)useCamera:(id)sender;
    

-(IBAction)Store:(id)sender;


@end
