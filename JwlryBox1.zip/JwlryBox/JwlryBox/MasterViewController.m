//
//  MasterViewController.m
//  JwlryBox
//
//  Created by Vidhi Shah on 4/6/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import "MasterViewController.h"

#import "InsertViewController.h"

#import "DetailViewController.h"
#import "Database.h"
#import "CategoryViewController.h"

@interface MasterViewController () {
    NSMutableArray *_objects;
}
@end

@implementation MasterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Master", @"Master");
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            self.clearsSelectionOnViewWillAppear = NO;
            self.contentSizeForViewInPopover = CGSizeMake(320.0, 600.0);
        }
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
  //  self.navigationItem.leftBarButtonItem = self.editButtonItem;

    self.navigationItem.title = @"Jewellery Box";


    int count;
    aryCount = [[NSMutableArray alloc]init];
    dataArray = [NSMutableArray arrayWithObjects: @"All", @"Rings", @"Earings",@"Necklace",@"Bangles",@"Other", nil];
    
    NSString *dbcategory;
    for(int i =0; i <dataArray.count; i++)
    {
        
        
        if (i==0) {
             dbcategory =[NSString stringWithFormat:@"select * from Jewellery"];
            
        }
        else{
     dbcategory =[NSString stringWithFormat:@"select * from Jewellery where j_Category='%@'",dataArray[i]];
        }
        dataArray1 = [Database executeQuery:dbcategory];
     count = dataArray1.count;
        
        NSString* myNewString = [NSString stringWithFormat:@"%i", count];
        [aryCount addObject:myNewString];
    }

    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)insertNewObject:(id)sender
{
//    if (!_objects) {
//        _objects = [[NSMutableArray alloc] init];
//    }
//    [_objects insertObject:[NSDate date] atIndex:0];
//    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
//    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
   
    
    InsertViewController *obj_Detail =[[ InsertViewController alloc] initWithNibName:@"InsertViewController" bundle:nil];

    
    [self.navigationController pushViewController:obj_Detail animated:YES];
   // [obj_Detail release];

}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataArray count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
    }
   	cell.textLabel.numberOfLines=1;
    
    
    
    UILabel *lblDesc =[[UILabel alloc]init];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    lblDesc.textColor=[UIColor blackColor];
    lblDesc.frame=CGRectMake(100, -10, 185, 65);
    lblDesc.numberOfLines = 2;
    lblDesc.backgroundColor=[UIColor clearColor];
    NSString *strDesc = [dataArray objectAtIndex:indexPath.row];
    lblDesc.text=strDesc;
    lblDesc.font = [UIFont systemFontOfSize:17];
    lblDesc.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
    [[cell contentView] addSubview:lblDesc];
    
    UILabel *lblWeight =[[UILabel alloc]init];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    lblWeight.textColor=[UIColor blackColor];
    lblWeight.frame=CGRectMake(100, 20, 185, 65 );
    lblWeight.numberOfLines = 2;
    lblWeight.backgroundColor=[UIColor clearColor];
    NSString *strWeight = [aryCount objectAtIndex:indexPath.row];
    strWeight = [strWeight stringByAppendingString:@" gms "];
    lblWeight.text=strWeight;
    lblWeight.font = [UIFont systemFontOfSize:17];
    lblWeight.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
    [[cell contentView] addSubview:lblWeight];

    
    
    
    
//    cell.textLabel.text = [dataArray objectAtIndex:indexPath.row];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [_objects removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CategoryViewController *obj_Detail =[[ CategoryViewController alloc] initWithNibName:@"CategoryViewController" bundle:nil];
    
    NSString *strCat = [dataArray objectAtIndex:indexPath.row];
    //NSString *strCat = [dict1 objectForKey:@"j_Category"];
    
    
    obj_Detail.category = strCat;
    
    [self.navigationController pushViewController:obj_Detail animated:YES];


    
//    NSDate *object = _objects[indexPath.row];
//    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
//	    if (!self.detailViewController) {
//	        self.detailViewController = [[DetailViewController alloc] initWithNibName:@"DetailViewController_iPhone" bundle:nil];
//	    }
//	    self.detailViewController.detailItem = object;
//        [self.navigationController pushViewController:self.detailViewController animated:YES];
//    } else {
//        self.detailViewController.detailItem = object;
//    }
}

@end
