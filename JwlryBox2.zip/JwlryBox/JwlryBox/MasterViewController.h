//
//  MasterViewController.h
//  JwlryBox
//
//  Created by Vidhi Shah on 4/6/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray    *dataArray;
    NSMutableArray    *dataArray1;

    NSMutableArray *aryCount;


}

@property (strong, nonatomic) DetailViewController *detailViewController;

@end
