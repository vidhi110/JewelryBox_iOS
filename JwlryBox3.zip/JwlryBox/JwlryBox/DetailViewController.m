//
//  DetailViewController.m
//  JwlryBox
//
//  Created by Vidhi Shah on 4/6/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import "DetailViewController.h"

#import "Database.h"

@interface DetailViewController ()
@property (strong, nonatomic) UIPopoverController *masterPopoverController;
- (void)configureView;
@end

@implementation DetailViewController
@synthesize category;

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem
{
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        // Update the view.
        [self configureView];
    }

    if (self.masterPopoverController != nil) {
        [self.masterPopoverController dismissPopoverAnimated:YES];
    }        
}

- (void)configureView
{
    // Update the user interface for the detail item.

    if (self.detailItem) {
        self.detailDescriptionLabel.text = [self.detailItem description];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self configureView];
    
    NSString *dbcategory;
if (category == @"All")
{
    dbcategory =[NSString stringWithFormat:@"select * from Jewellery"];

}
else{
    
    
    dbcategory =[NSString stringWithFormat:@"select * from Jewellery where j_Category='%@'",category];
}
    dataArray = [Database executeQuery:dbcategory];


}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = category;
    }
    return self;
}


#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataArray count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    
//    static NSString *CellIdentifier = @"Cell";
//    
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//    
//    
//    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
//   //	cell.textLabel.numberOfLines=1;
//    
//    UILabel *lblDesc =[[UILabel alloc]init];
//    UILabel *lblPrice =[[UILabel alloc]init];
//
//    UILabel *lblWeight =[[UILabel alloc]init];
//
//    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
//    
//    lblDesc.textColor=[UIColor blackColor];
//   lblDesc.frame=CGRectMake(80, -5, 185, 65);
//    
//    NSDictionary *dict1=[dataArray objectAtIndex:indexPath.row];
//    NSString *strDesc = [dict1 objectForKey:@"j_Desc"];
//    NSString *strWeight = [dict1 objectForKey:@"j_Weight"];
//    NSString *strPrice = [dict1 objectForKey:@"j_Price"];
//    
//    
//    cell.textLabel.text = strDesc;
//
//    
//   // lblDesc.text=strDesc;
//   // lblWeight.text=strWeight;
//
//    //lblPrice.text=strDesc;
//
//  //  lblDesc.font = [UIFont systemFontOfSize:17];
//   // lblDesc.baselineAdjustment=UIBaselineAdjustmentAlignCenters;
//    
//  // [[cell contentView] addSubview:lblDesc];
//  //  [[cell contentView] addSubview:lblWeight];
//
//    //[[cell contentView] addSubview:lblPrice];
//
////    [cell.contentView addSubview:lblDesc];
////    [cell.contentView addSubview:lblWeight];
////
////    [cell.contentView addSubview:lblPrice];
//
//
//    
//    
////    NSString *strImage = [dict1 objectForKey:@"j_Image"];
////    UIImage *img = [UIImage imageNamed:[NSString stringWithFormat:@"%@_small.jpg",strImage]];
////    UIImageView *imageView = [[UIImageView alloc]init];
////    
////    
////    thumbnail=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"thumbnail.png"]];
////    thumbnail.frame = CGRectMake(15,12,50,40);
////    
////    
////    [cell.contentView addSubview:thumbnail];
////    
////    imageView.image  =img;
////    imageView.frame = CGRectMake(18,15,45,35);// 25....
//   // [[cell contentView] addSubview:imageView];
//    
//    return cell;

    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
    }
    
    cell.textLabel.text = @"Desc";
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if (editingStyle == UITableViewCellEditingStyleDelete) {
//        [_objects removeObjectAtIndex:indexPath.row];
//        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
//    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
//        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
//    }
}



							
#pragma mark - Split view

- (void)splitViewController:(UISplitViewController *)splitController willHideViewController:(UIViewController *)viewController withBarButtonItem:(UIBarButtonItem *)barButtonItem forPopoverController:(UIPopoverController *)popoverController
{
    barButtonItem.title = NSLocalizedString(@"Master", @"Master");
    [self.navigationItem setLeftBarButtonItem:barButtonItem animated:YES];
    self.masterPopoverController = popoverController;
}

- (void)splitViewController:(UISplitViewController *)splitController willShowViewController:(UIViewController *)viewController invalidatingBarButtonItem:(UIBarButtonItem *)barButtonItem
{
    // Called when the view is shown again in the split view, invalidating the button and popover controller.
    [self.navigationItem setLeftBarButtonItem:nil animated:YES];
    self.masterPopoverController = nil;
}

@end
