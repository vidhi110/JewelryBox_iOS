//
//  DetailViewController.h
//  JwlryBox
//
//  Created by Vidhi Shah on 4/6/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController <UISplitViewControllerDelegate,UITableViewDataSource,UITableViewDelegate>

{
    //IBOutlet UITableView *tableView;
    NSMutableArray    *dataArray;
    IBOutlet UIImageView    *thumbnail;
    IBOutlet UIImageView    *imgCell;

    NSString *category;
}

@property (strong, nonatomic) NSString *detailItem;

@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;
@property (strong, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic,retain) NSString *category;

@end
