//
//  AppDelegate.h
//  JwlryBox
//
//  Created by Vidhi Shah on 4/6/13.
//  Copyright (c) 2013 Vidhi Shah. All rights reserved.
//
#import "Database.h"
#import "FBConnect.h"

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,FBRequestDelegate,FBDialogDelegate,FBSessionDelegate>
{
    UIActivityIndicatorView *indicator;
    //Facebook
    Facebook *facebook;
    NSMutableDictionary *userPermissions;
    NSArray *permissions;
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController *navigationController;

@property (strong, nonatomic) UISplitViewController *splitViewController;
@property(nonatomic,retain)IBOutlet UIActivityIndicatorView *indicator;

//Facebook
@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic, retain) NSArray *permissions;
@property (nonatomic, retain) NSMutableDictionary *userPermissions;

- (void)showLoggedIn;
- (void)uploadFeed:(NSMutableDictionary *)dictFacebookInformation;
- (void)createEditableCopyOfDatabaseIfNeeded;



@end
